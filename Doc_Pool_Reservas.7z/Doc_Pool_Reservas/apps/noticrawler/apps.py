from django.apps import AppConfig


class NoticrawlerConfig(AppConfig):
    name = 'noticrawler'
