var BASE_URL = '/api'

function getDocuments() {
    return axios.get(BASE_URL + '/document')
}