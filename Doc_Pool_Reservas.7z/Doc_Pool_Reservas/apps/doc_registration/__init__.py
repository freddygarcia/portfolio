default_app_config = 'apps.doc_registration.apps.DocRegistrationConfig'
