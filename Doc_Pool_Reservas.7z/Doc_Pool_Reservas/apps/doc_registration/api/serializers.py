from rest_framework import serializers

from apps.doc_registration.models import *


class AreaSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Area
        fields = ['id', 'name']


class CategorySerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name']


class SourceSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Source
        fields = ['id', 'name']


class MandateSerializer(serializers.ModelSerializer):

    tests = serializers.PrimaryKeyRelatedField(
        many=True, read_only=True
    )

    class Meta:
        model = Mandate
        fields = '__all__'


class DocumentDetailsSerializer(serializers.ModelSerializer):

    mandates = serializers.PrimaryKeyRelatedField(
        many=True, read_only=True
    )

    class Meta:
        model = DocumentDetails
        fields = ['id', 'link', 'file_name',
                  'document_date', 'document', 'mandates']


class DocumentSerializer(serializers.ModelSerializer):

    document_details = serializers.PrimaryKeyRelatedField(
        many=True, read_only=True
    )

    class Meta:
        model = Document
        depth = 1
        fields = ['id', 'title', 'description', 'document_details']


class MandateTestSerializer(serializers.ModelSerializer):

    class Meta:
        model = MandateTest
        fields = '__all__'
