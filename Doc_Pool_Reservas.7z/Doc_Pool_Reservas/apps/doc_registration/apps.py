from django.apps import AppConfig


class DocRegistrationConfig(AppConfig):
    name = 'apps.doc_registration'
    verbose_name = "Pool de Documentos"

