from django.contrib import admin

admin.site.site_header = 'Registro de Documentos'
